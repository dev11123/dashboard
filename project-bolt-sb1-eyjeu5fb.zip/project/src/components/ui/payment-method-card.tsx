import React from 'react';
import { Card, CardContent } from './card';
import { Button } from './button';
import { Badge } from './badge';
import { CreditCardIcon, TrashIcon } from 'lucide-react';
import { cn } from '../../lib/utils';

interface PaymentMethod {
  id: string;
  type: 'card' | 'bank' | 'wallet';
  name: string;
  details: string;
  isDefault: boolean;
  expiryDate?: string;
}

interface PaymentMethodCardProps {
  paymentMethod: PaymentMethod;
  onSetDefault?: (id: string) => void;
  onDelete?: (id: string) => void;
  className?: string;
}

export const PaymentMethodCard: React.FC<PaymentMethodCardProps> = ({
  paymentMethod,
  onSetDefault,
  onDelete,
  className
}) => {
  const getIcon = () => {
    switch (paymentMethod.type) {
      case 'card':
        return <CreditCardIcon className="w-6 h-6" />;
      case 'bank':
        return <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">B</div>;
      case 'wallet':
        return <div className="w-6 h-6 bg-purple-600 rounded flex items-center justify-center text-white text-xs font-bold">W</div>;
      default:
        return <CreditCardIcon className="w-6 h-6" />;
    }
  };

  return (
    <Card className={cn("hover:shadow-md transition-shadow duration-200", className)}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <div className="text-gray-600">
              {getIcon()}
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h4 className="text-sm font-medium text-gray-900">{paymentMethod.name}</h4>
                {paymentMethod.isDefault && (
                  <Badge className="bg-blue-100 text-blue-800 text-xs">Default</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mt-1">{paymentMethod.details}</p>
              {paymentMethod.expiryDate && (
                <p className="text-xs text-gray-500 mt-1">Expires: {paymentMethod.expiryDate}</p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {!paymentMethod.isDefault && onSetDefault && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onSetDefault(paymentMethod.id)}
                className="text-xs"
              >
                Set Default
              </Button>
            )}
            {onDelete && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDelete(paymentMethod.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <TrashIcon className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};