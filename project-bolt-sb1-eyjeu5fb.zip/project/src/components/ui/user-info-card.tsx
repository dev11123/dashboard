import React from 'react';
import { Card, CardContent } from './card';
import { UserIcon, IdCardIcon } from 'lucide-react';

interface UserInfoCardProps {
  userId: string;
  userName: string;
  userEmail?: string;
  avatarUrl?: string;
}

export const UserInfoCard: React.FC<UserInfoCardProps> = ({
  userId,
  userName,
  userEmail,
  avatarUrl
}) => {
  return (
    <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white border-0 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center space-x-4">
          {/* Avatar or User Icon */}
          <div className="flex-shrink-0">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={userName}
                className="w-16 h-16 rounded-full border-2 border-white/20"
              />
            ) : (
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <UserIcon className="w-8 h-8 text-white" />
              </div>
            )}
          </div>

          {/* User Information */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-2">
              <IdCardIcon className="w-4 h-4 text-white/80" />
              <span className="text-sm font-medium text-white/80">User ID</span>
            </div>
            <p className="text-lg font-bold text-white mb-1">{userId}</p>
            
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white truncate">{userName}</h3>
              {userEmail && (
                <p className="text-sm text-white/80 truncate">{userEmail}</p>
              )}
            </div>
          </div>
        </div>

        {/* Status Indicator */}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-sm text-white/80">Active</span>
          </div>
          <div className="text-right">
            <p className="text-xs text-white/60">Member since</p>
            <p className="text-sm font-medium text-white">Jan 2024</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};