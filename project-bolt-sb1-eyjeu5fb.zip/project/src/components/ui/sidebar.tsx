import React from 'react';
import { cn } from '../../lib/utils';
import {
  HomeIcon,
  CreditCardIcon,
  HistoryIcon,
  SettingsIcon,
  HelpCircleIcon,
  BarChart3Icon,
  WalletIcon,
  UserIcon
} from 'lucide-react';

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  active?: boolean;
}

interface SidebarProps {
  activeItem: string;
  onItemClick: (itemId: string) => void;
  className?: string;
}

const sidebarItems: SidebarItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon className="w-5 h-5" /> },
  { id: 'transactions', label: 'Transactions', icon: <HistoryIcon className="w-5 h-5" /> },
  { id: 'payment-methods', label: 'Payment Methods', icon: <CreditCardIcon className="w-5 h-5" /> },
  { id: 'analytics', label: 'Analytics', icon: <BarChart3Icon className="w-5 h-5" /> },
  { id: 'wallet', label: 'Wallet', icon: <WalletIcon className="w-5 h-5" /> },
  { id: 'profile', label: 'Profile', icon: <UserIcon className="w-5 h-5" /> },
  { id: 'settings', label: 'Settings', icon: <SettingsIcon className="w-5 h-5" /> },
  { id: 'help', label: 'Help & Support', icon: <HelpCircleIcon className="w-5 h-5" /> },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeItem,
  onItemClick,
  className
}) => {
  return (
    <div className={cn("w-64 bg-white border-r border-gray-200 h-full", className)}>
      <div className="p-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <CreditCardIcon className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-gray-900">PayGateway</h1>
        </div>
      </div>
      
      <nav className="px-4 pb-4">
        <ul className="space-y-1">
          {sidebarItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => onItemClick(item.id)}
                className={cn(
                  "w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors duration-200",
                  activeItem === item.id
                    ? "bg-blue-50 text-blue-700 border-r-2 border-blue-700"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};