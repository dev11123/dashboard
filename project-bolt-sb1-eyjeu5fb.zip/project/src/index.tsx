import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { PaymentDashboard } from "./screens/PaymentDashboard";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <PaymentDashboard />
  </StrictMode>,
);