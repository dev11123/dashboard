import React, { useState } from 'react';
import { Sidebar } from '../../components/ui/sidebar';
import { Header } from '../../components/ui/header';
import { StatCard } from '../../components/ui/stat-card';
import { TransactionTable } from '../../components/ui/transaction-table';
import { PaymentMethodCard } from '../../components/ui/payment-method-card';
import { UserInfoCard } from '../../components/ui/user-info-card';
import { Card, CardContent, CardHeader } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import {
  DollarSignIcon,
  TrendingUpIcon,
  CreditCardIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  PlusIcon
} from 'lucide-react';

// Mock data
const mockTransactions = [
  {
    id: 'TXN001',
    date: '2024-01-15',
    description: 'Online Purchase - Amazon',
    amount: 129.99,
    status: 'completed' as const,
    type: 'debit' as const,
    method: 'Visa ****1234'
  },
  {
    id: 'TXN002',
    date: '2024-01-14',
    description: 'Salary Deposit',
    amount: 5000.00,
    status: 'completed' as const,
    type: 'credit' as const,
    method: 'Bank Transfer'
  },
  {
    id: 'TXN003',
    date: '2024-01-13',
    description: 'Subscription - Netflix',
    amount: 15.99,
    status: 'pending' as const,
    type: 'debit' as const,
    method: 'Mastercard ****5678'
  },
  {
    id: 'TXN004',
    date: '2024-01-12',
    description: 'Refund - Store Return',
    amount: 89.50,
    status: 'completed' as const,
    type: 'credit' as const,
    method: 'Visa ****1234'
  },
  {
    id: 'TXN005',
    date: '2024-01-11',
    description: 'Gas Station',
    amount: 45.20,
    status: 'failed' as const,
    type: 'debit' as const,
    method: 'Debit Card ****9012'
  }
];

const mockPaymentMethods = [
  {
    id: 'pm1',
    type: 'card' as const,
    name: 'Visa Ending in 1234',
    details: '•••• •••• •••• 1234',
    isDefault: true,
    expiryDate: '12/26'
  },
  {
    id: 'pm2',
    type: 'card' as const,
    name: 'Mastercard Ending in 5678',
    details: '•••• •••• •••• 5678',
    isDefault: false,
    expiryDate: '08/25'
  },
  {
    id: 'pm3',
    type: 'bank' as const,
    name: 'Chase Bank Account',
    details: 'Checking ••••••••9012',
    isDefault: false
  }
];

// Mock user data
const mockUser = {
  userId: 'USR-2024-001',
  userName: 'Ahmed Hassan',
  userEmail: 'ahmed.hassan@email.com',
  avatarUrl: undefined // Will show default user icon
};

export const PaymentDashboard: React.FC = () => {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderDashboardContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* User Info Card - First Element */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <UserInfoCard
                  userId={mockUser.userId}
                  userName={mockUser.userName}
                  userEmail={mockUser.userEmail}
                  avatarUrl={mockUser.avatarUrl}
                />
              </div>
              
              {/* Quick Actions moved to right side */}
              <div className="lg:col-span-2">
                <Card className="h-full">
                  <CardHeader>
                    <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <Button className="h-12 flex-col space-y-1" variant="outline">
                        <PlusIcon className="w-4 h-4" />
                        <span className="text-xs">Send Money</span>
                      </Button>
                      <Button className="h-12 flex-col space-y-1" variant="outline">
                        <PlusIcon className="w-4 h-4" />
                        <span className="text-xs">Request Payment</span>
                      </Button>
                      <Button className="h-12 flex-col space-y-1" variant="outline">
                        <PlusIcon className="w-4 h-4" />
                        <span className="text-xs">Add Card</span>
                      </Button>
                      <Button className="h-12 flex-col space-y-1" variant="outline">
                        <PlusIcon className="w-4 h-4" />
                        <span className="text-xs">Pay Bills</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Total Balance"
                value="$12,459.32"
                change="+2.5% from last month"
                changeType="positive"
                icon={<DollarSignIcon className="w-6 h-6" />}
              />
              <StatCard
                title="Monthly Income"
                value="$8,240.00"
                change="+12.3% from last month"
                changeType="positive"
                icon={<ArrowUpIcon className="w-6 h-6" />}
              />
              <StatCard
                title="Monthly Expenses"
                value="$3,891.45"
                change="-5.2% from last month"
                changeType="positive"
                icon={<ArrowDownIcon className="w-6 h-6" />}
              />
              <StatCard
                title="Active Cards"
                value="3"
                change="1 expires soon"
                changeType="neutral"
                icon={<CreditCardIcon className="w-6 h-6" />}
              />
            </div>

            {/* Charts and Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold text-gray-900">Spending Overview</h3>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <TrendingUpIcon className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">Chart visualization would go here</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockTransactions.slice(0, 4).map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                        <div className="flex-1">
                          <p className="font-medium text-sm text-gray-900">{transaction.description}</p>
                          <p className="text-xs text-gray-500">{transaction.date}</p>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold text-sm ${
                            transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transaction.type === 'credit' ? '+' : '-'}${transaction.amount}
                          </p>
                          <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                            transaction.status === 'completed' ? 'bg-green-100 text-green-800' :
                            transaction.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {transaction.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Transactions Table */}
            <TransactionTable transactions={mockTransactions.slice(0, 5)} />
          </div>
        );

      case 'transactions':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">All Transactions</h2>
              <div className="flex space-x-2">
                <Button variant="outline">Filter</Button>
                <Button variant="outline">Export</Button>
              </div>
            </div>
            <TransactionTable transactions={mockTransactions} />
          </div>
        );

      case 'payment-methods':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Payment Methods</h2>
              <Button>
                <PlusIcon className="w-4 h-4 mr-2" />
                Add New Method
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockPaymentMethods.map((method) => (
                <PaymentMethodCard
                  key={method.id}
                  paymentMethod={method}
                  onSetDefault={(id) => console.log('Set default:', id)}
                  onDelete={(id) => console.log('Delete:', id)}
                />
              ))}
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Analytics & Reports</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold text-gray-900">Monthly Trends</h3>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Monthly trends chart</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <h3 className="text-lg font-semibold text-gray-900">Category Breakdown</h3>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                    <p className="text-gray-500">Category pie chart</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return (
          <div className="flex items-center justify-center h-64">
            <p className="text-gray-500">Content for {activeSection} section</p>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar activeItem={activeSection} onItemClick={setActiveSection} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6">
          {renderDashboardContent()}
        </main>
      </div>
    </div>
  );
};