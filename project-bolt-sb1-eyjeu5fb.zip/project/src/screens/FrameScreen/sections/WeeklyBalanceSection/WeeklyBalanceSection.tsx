import { SettingsIcon } from "lucide-react";
import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const WeeklyBalanceSection = (): JSX.Element => {
  // Data for the decorative lines
  const decorativeLines = [
    { top: "13px", left: "96px", rotate: "-15deg" },
    { top: "10px", left: "0", rotate: "-15deg" },
    { top: "38px", left: "8px", rotate: "-15deg" },
    {
      top: "35px",
      left: "96px",
      rotate: "-15deg",
      transform: "rotate(180deg)",
    },
    { top: "38px", left: "0", rotate: "-15deg", transform: "rotate(180deg)" },
    { top: "10px", left: "8px", rotate: "-15deg", transform: "rotate(180deg)" },
  ];

  // Data for the indicator dots
  const indicatorDots = [{ top: "117px" }, { top: "153px" }, { top: "189px" }];

  return (
    <div className="relative w-full max-w-[608px] h-[270px] rounded-[34px]">
      <Card className="relative w-full h-full bg-[url(/subtract-24.svg)] bg-[100%_100%] overflow-hidden rounded-[34px] border-0">
        <CardContent className="p-0 h-full">
          {/* Decorative background lines */}
          <div className="relative h-[89px] w-[246px] mt-7 ml-9">
            {decorativeLines.map((line, index) => (
              <div
                key={index}
                className="absolute w-[79px] h-[11px] bg-[#ffffff3d] rounded-[100px]"
                style={{
                  top: line.top,
                  left: line.left,
                  transform: `rotate(${line.rotate}) ${line.transform || ""}`,
                }}
              />
            ))}
          </div>

          {/* Content section */}
          <div className="absolute w-[141px] h-[114px] top-[31px] left-6">
            <h3 className="font-medium text-[#131215] text-base tracking-[0.48px] font-['Poppins',Helvetica]">
              Weekly Balance
            </h3>
            <p className="mt-10 font-medium text-[#131215] text-[32px] tracking-[0.96px] font-['Poppins',Helvetica]">
              $20k
            </p>
            <button className="mt-6 font-normal text-[#131215] text-xs tracking-[0.36px] underline font-['Poppins',Helvetica]">
              View entire list
            </button>
          </div>

          {/* Indicator dots */}
          <div className="absolute right-6 top-[117px] flex flex-col gap-9">
            {indicatorDots.map((dot, index) => (
              <div key={index} className="w-6 h-1.5 bg-black rounded-full" />
            ))}
          </div>

          {/* Image */}
          <img
            className="absolute w-[159px] h-[131px] bottom-[5px] right-[16px]"
            alt="Financial illustration"
            src="/image.png"
          />
        </CardContent>
      </Card>

      {/* SettingsIcon button */}
      <div className="flex flex-col w-[172px] items-start justify-center gap-2.5 px-5 py-5 absolute top-[131px] left-[-172px] bg-[#242632] rounded-xl">
        <div className="flex items-center gap-4 relative self-stretch w-full">
          <SettingsIcon className="w-6 h-6 text-white" />
          <span className="relative flex-1 font-['Manrope',Helvetica] font-medium text-white text-lg">
            SettingsIcon
          </span>
        </div>
      </div>
    </div>
  );
};
