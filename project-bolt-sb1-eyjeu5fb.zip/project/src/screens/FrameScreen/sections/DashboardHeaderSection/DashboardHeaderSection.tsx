import { ChevronDownIcon, ChevronLeftIcon } from "lucide-react";
import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const DashboardHeaderSection = (): JSX.Element => {
  // Calendar data
  const daysOfWeek = ["S", "M", "T", "W", "T", "F", "S"];
  const calendarDays = [
    { day: "27", isCurrentMonth: false },
    { day: "28", isCurrentMonth: false },
    { day: "29", isCurrentMonth: false },
    { day: "30", isCurrentMonth: false },
    { day: "31", isCurrentMonth: false },
    { day: "1", isCurrentMonth: true },
    { day: "2", isCurrentMonth: true },
    { day: "3", isCurrentMonth: true, isHighlighted: true },
    { day: "4", isCurrentMonth: true, isHighlighted: true },
    { day: "5", isCurrentMonth: true, isHighlighted: true },
    { day: "6", isCurrentMonth: true, isHighlighted: true },
    { day: "7", isCurrentMonth: true, isHighlighted: true },
    { day: "8", isCurrentMonth: true },
    { day: "9", isCurrentMonth: true },
    { day: "10", isCurrentMonth: true },
    { day: "11", isCurrentMonth: true },
    { day: "12", isCurrentMonth: true },
    { day: "13", isCurrentMonth: true },
    { day: "14", isCurrentMonth: true },
    { day: "15", isCurrentMonth: true },
    { day: "16", isCurrentMonth: true },
    { day: "17", isCurrentMonth: true },
    { day: "18", isCurrentMonth: true },
    { day: "19", isCurrentMonth: true },
    { day: "20", isCurrentMonth: true },
    { day: "21", isCurrentMonth: true },
    { day: "22", isCurrentMonth: true },
    { day: "23", isCurrentMonth: true },
    { day: "24", isCurrentMonth: true },
    { day: "25", isCurrentMonth: true },
    { day: "26", isCurrentMonth: true },
    { day: "27", isCurrentMonth: true },
    { day: "28", isCurrentMonth: true },
    { day: "29", isCurrentMonth: false },
    { day: "30", isCurrentMonth: false },
  ];

  return (
    <Card className="w-full max-w-[486px] h-[286px] bg-[#161717] rounded-[32px] border-none">
      <CardContent className="p-6">
        <div className="flex flex-col h-full">
          <div className="flex items-center mb-4">
            <h3 className="font-bold text-base text-white font-['Poppins',Helvetica]">
              Calendar
            </h3>
          </div>

          <div className="flex flex-col space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg border border-solid border-[#515151]">
                <ChevronLeftIcon className="w-[13px] h-[13px] text-white" />
                <span className="font-['Poppins',Helvetica] font-medium text-white text-xs">
                  Feb&nbsp;&nbsp;2023
                </span>
                <ChevronDownIcon className="w-3.5 h-3.5 text-white" />
              </div>

              <a
                href="#"
                className="font-['Poppins',Helvetica] font-normal text-white text-xs tracking-[0.36px] underline"
              >
                View
              </a>
            </div>

            <div className="relative mt-2">
              {/* Highlight for current week */}
              <div className="absolute w-[299px] h-[26px] top-[49px] left-0 bg-[#FFCC33]/20 rounded-full z-0"></div>

              <div className="grid grid-cols-7 gap-x-8 gap-y-3 relative z-10">
                {/* Days of week headers */}
                {daysOfWeek.map((day, index) => (
                  <div
                    key={`header-${index}`}
                    className="text-center font-['Poppins',Helvetica] font-normal text-[#515151] text-xs"
                  >
                    {day}
                  </div>
                ))}

                {/* Calendar days */}
                {calendarDays.map((day, index) => (
                  <div
                    key={`day-${index}`}
                    className={`text-center font-['Poppins',Helvetica] font-medium text-xs
                      ${day.isCurrentMonth ? "text-white" : "text-[#373455]"}
                      ${day.isHighlighted ? "text-black" : ""}
                    `}
                  >
                    {day.day}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
