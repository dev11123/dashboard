import { HomeIcon, SearchIcon, VaultIcon } from "lucide-react";
import React from "react";

// Navigation items data for easy mapping
const navigationItems = [
  {
    icon: <SearchIcon className="w-6 h-6" />,
    label: "Text",
    alt: "Discovery icon",
    iconSrc: "/discoveryicon.svg",
    active: false,
  },
  {
    icon: <VaultIcon className="w-6 h-6" />,
    label: "Text",
    alt: "Vault icon",
    iconSrc: "/vaulticon.svg",
    active: false,
  },
  {
    icon: <HomeIcon className="w-6 h-6" />,
    label: "Text",
    alt: "House icon",
    iconSrc: "/houseicon.svg",
    active: true,
  },
];

export const BottomNavigationSection = (): JSX.Element => {
  return (
    <nav className="w-full h-[78px] bg-[#242632] flex justify-around items-center">
      {navigationItems.map((item, index) => (
        <div key={index} className="flex flex-col items-center gap-0.5">
          {/* Using the SVG from the original code for consistency */}
          <img className="w-6 h-6" alt={item.alt} src={item.iconSrc} />
          <div
            className={`w-fit text-[10px] tracking-[0.40px] leading-normal whitespace-nowrap text-white ${
              item.active
                ? "[font-family:'SF_Pro_Display-Medium',Helvetica] font-medium"
                : "[font-family:'SF_Pro_Display-Light',Helvetica] font-light"
            }`}
          >
            {item.label}
          </div>
        </div>
      ))}
    </nav>
  );
};
