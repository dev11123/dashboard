import { CheckIcon } from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Feature list data
const features = [
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
];

export const SearchSection = (): JSX.Element => {
  return (
    <Card className="relative w-full max-w-[363px] h-[201px] border border-solid border-black backdrop-blur-[2px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(2px)_brightness(100%)] [background:url(..//frame-9092.png)_50%_50%_/_cover]">
      <CardContent className="p-0">
        {/* Digital badge and description */}
        <div className="flex flex-col w-[172px] h-[74px] items-start gap-[15px] bg-[#00000029]">
          <div className="relative w-[88px] h-6">
            <Badge className="flex w-[88px] h-6 items-center justify-center gap-[9.23px] px-[13.85px] py-[5.54px] bg-[#f1f1f1] rounded-[5.54px]">
              <span className="relative w-[65px] h-6 mt-[-6.46px] mb-[-4.62px] ml-[-2.35px] mr-[-2.35px] [font-family:'Poppins',Helvetica] font-extrabold text-color-4 text-base text-center tracking-[0.16px] leading-[27.7px] whitespace-nowrap">
                DIGITAL
              </span>
            </Badge>
          </div>

          <div className="relative w-[164px] h-7 [font-family:'Poppins',Helvetica] font-light text-white text-[9px] tracking-[0] leading-normal">
            For all individuals and starters who
            <br />
            want to start with domaining.
          </div>
        </div>

        {/* Price section */}
        <div className="mt-[8px] ml-0 flex flex-col w-[197px] h-[70px] items-start">
          <div className="relative w-[194px] h-[70px] mt-[-1.00px] [font-family:'Poppins',Helvetica] font-semibold text-white text-[32px] tracking-[-0.22px] leading-[73.1px] whitespace-nowrap">
            <span className="tracking-[-0.07px]">$49</span>
            <span className="text-[11px] tracking-[-0.01px]">
              .99&nbsp;&nbsp;{" "}
            </span>
            <span className="text-sm tracking-[-0.01px]">USD / month</span>
          </div>
        </div>

        {/* Features list */}
        <div className="absolute w-[130px] h-[111px] top-[81px] right-0">
          <div className="relative w-[143px] h-[97px]">
            {features.map((feature, index) => (
              <div key={index} className="relative w-[145px] h-[23px] mb-[4px]">
                <div className="absolute w-[124px] top-0 left-[19px] [font-family:'Poppins',Helvetica] font-normal text-white text-[8px] tracking-[0] leading-[24.0px] whitespace-nowrap">
                  {feature}
                </div>
                <div className="absolute w-[15px] h-3.5 top-[5px] left-0">
                  <CheckIcon className="absolute w-[11px] h-2.5 top-0.5 left-0.5 text-white" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <Button
          variant="default"
          className="flex w-[157px] h-[21px] items-center justify-center gap-[9.23px] px-[64.62px] py-[18.46px] absolute bottom-4 left-2 bg-white rounded-[3.69px] hover:bg-white/90"
        >
          <span className="relative w-fit mt-[-20.39px] mb-[-18.54px] ml-[-35.62px] mr-[-35.62px] [font-family:'Roboto',Helvetica] font-bold text-black text-[10px] text-center tracking-[0] leading-[22.2px] whitespace-nowrap">
            Start free 14-day Trial
          </span>
        </Button>
      </CardContent>
    </Card>
  );
};
