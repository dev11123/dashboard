import { CheckIcon } from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent, CardFooter } from "../../../../components/ui/card";

// Features data for the pricing card
const features = [
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
  "Access to All Features",
];

export const MainContentSection = (): JSX.Element => {
  return (
    <Card
      className="relative w-full max-w-[363px] h-auto border border-solid border-black overflow-hidden bg-cover bg-center"
      style={{ backgroundImage: "url(../frame-9092.png)" }}
    >
      <div className="absolute inset-0 backdrop-blur-[2px] backdrop-brightness-100"></div>

      <CardContent className="relative z-10 p-0">
        {/* Header section with badge and description */}
        <div className="flex flex-col w-full max-w-[172px] p-4 gap-[15px] bg-[#00000029]">
          <Badge
            variant="outline"
            className="w-fit h-6 flex items-center justify-center px-[13.85px] py-[5.54px] bg-[#f1f1f1] rounded-[5.54px]"
          >
            <span className="font-['Poppins',Helvetica] font-extrabold text-color-4 text-base text-center tracking-[0.16px] leading-[27.7px]">
              DIGITAL
            </span>
          </Badge>

          <p className="font-['Poppins',Helvetica] font-light text-white text-[9px] leading-normal">
            For all individuals and starters who
            <br />
            want to start with domaining.
          </p>
        </div>

        {/* Pricing section */}
        <div className="flex flex-col w-full p-4 pt-0">
          <div className="font-['Poppins',Helvetica] font-semibold text-white text-[32px] tracking-[-0.22px] leading-[73.1px] whitespace-nowrap">
            <span className="tracking-[-0.07px]">$49</span>
            <span className="text-[11px] tracking-[-0.01px]">
              .99&nbsp;&nbsp;{" "}
            </span>
            <span className="text-sm tracking-[-0.01px]">USD / month</span>
          </div>
        </div>

        {/* Features list */}
        <div className="flex flex-col gap-1 p-4 pt-0">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="flex-shrink-0 w-[15px] h-3.5 flex items-center justify-center">
                <CheckIcon className="w-[11px] h-2.5 text-white" />
              </div>
              <span className="font-['Poppins',Helvetica] font-normal text-white text-[8px] leading-[24px]">
                {feature}
              </span>
            </div>
          ))}
        </div>
      </CardContent>

      <CardFooter className="p-2">
        <Button className="w-full h-[21px] bg-white text-black rounded-[3.69px] hover:bg-gray-100">
          <span className="font-['Roboto',Helvetica] font-bold text-[10px] leading-[22.2px]">
            Start free 14-day Trial
          </span>
        </Button>
      </CardFooter>
    </Card>
  );
};
