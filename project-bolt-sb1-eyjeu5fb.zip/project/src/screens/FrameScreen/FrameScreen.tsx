import { CommandIcon, LayoutGridIcon, SearchIcon } from "lucide-react";
import React from "react";
import { Button } from "../../components/ui/button";

// Import all sections
import { BottomNavigationSection } from "./sections/BottomNavigationSection";
import { CalendarSection } from "./sections/CalendarSection";
import { DashboardHeaderSection } from "./sections/DashboardHeaderSection";
import { DigitalSubscriptionSection } from "./sections/DigitalSubscriptionSection";
import { MainContentSection } from "./sections/MainContentSection";
import { SearchSection } from "./sections/SearchSection";
import { SubscriptionCardsSection } from "./sections/SubscriptionCardsSection";
import { WeeklyBalanceSection } from "./sections/WeeklyBalanceSection";

export const FrameScreen = (): JSX.Element => {
  // Navigation items data
  const navigationItems = [
    {
      icon: <LayoutGridIcon className="w-6 h-6" />,
      label: "Dashboard",
      active: true,
    },
    {
      icon: <CommandIcon className="w-6 h-6" />,
      label: "Teams",
      active: false,
    },
  ];

  return (
    <div className="bg-black flex flex-row justify-center w-full">
      <div className="bg-black overflow-hidden w-[1284px] relative">
        {/* Top search bar */}
        <div className="w-full h-[111px] bg-[linear-gradient(90deg,rgba(206,195,195,1)_8%,rgba(166,179,178,1)_39%,rgba(149,172,170,1)_53%,rgba(222,230,228,1)_90%)]">
          <div className="relative w-[434px] h-14 left-52 bg-neutral-100 rounded-md">
            <div className="relative w-[188px] h-7 top-[13px] left-[17px] flex items-center">
              <SearchIcon className="w-[23px] h-7" />
              <span className="ml-2 font-normal text-[#787486] text-sm">
                SearchIcon for anything...
              </span>
            </div>
          </div>
        </div>

        {/* Sidebar navigation */}
        <div className="w-[174px] h-[442px] absolute top-[116px] -left-px">
          <img
            className="absolute w-[173px] h-[439px] top-[3px] left-0"
            alt="Rectangle"
            src="/rectangle.svg"
          />

          {navigationItems.map((item, index) => (
            <div
              key={item.label}
              className={`flex flex-col w-[168px] h-[51px] items-start justify-center gap-2.5 pl-0 pr-5 py-3 absolute ${
                index === 0 ? "top-0 left-[3px]" : "top-[67px] left-1.5"
              } ${item.active ? "bg-[#4f3c76]" : "bg-[#242632]"} rounded-lg`}
            >
              <div className="flex items-center gap-4 relative self-stretch w-full flex-[0_0_auto]">
                {item.icon}
                <div
                  className={`relative flex-1 mt-[-1.00px] [font-family:'Manrope',Helvetica] ${
                    item.active ? "font-bold" : "font-medium"
                  } text-white text-lg tracking-[0] leading-[normal]`}
                >
                  {item.label}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Weekly Balance Card */}
        <div className="absolute w-[608px] h-[270px] top-[113px] left-[175px] rounded-[34px]">
          <div className="absolute w-[141px] h-[114px] top-5 left-[5px]">
            <div className="absolute top-0 left-0 [font-family:'Poppins',Helvetica] font-medium text-[#131215] text-base tracking-[0.48px] leading-[normal]">
              Weekly Balance
            </div>
            <div className="absolute top-10 left-0 [font-family:'Poppins',Helvetica] font-medium text-[#131215] text-[32px] tracking-[0.96px] leading-[normal]">
              $20k
            </div>
            <div className="absolute w-[94px] top-24 left-0 [font-family:'Poppins',Helvetica] font-normal text-[#131215] text-xs tracking-[0.36px] leading-[normal] underline">
              View entire list
            </div>
          </div>
          <WeeklyBalanceSection />
        </div>

        {/* TEARMS Button */}
        <div className="flex w-[43px] h-[26px] items-center justify-center p-0.5 absolute top-[184px] left-[-151px]">
          <Button className="inline-flex items-center justify-center gap-2.5 px-[18px] py-4 relative flex-[0_0_auto] mt-[-12.00px] mb-[-12.00px] ml-[-24.00px] mr-[-24.00px] bg-white border-2 border-solid border-black shadow-[-4px_4px_0px_#000000] rounded-none">
            <span className="relative w-fit mt-[-2.00px] [font-family:'Source_Code_Pro',Helvetica] font-semibold text-black text-sm tracking-[0] leading-[14px] whitespace-nowrap">
              TEARMS
            </span>
          </Button>
        </div>

        {/* Main content layout */}
        <div className="flex flex-col w-full mt-[111px]">
          {/* Dashboard Header */}
          <DashboardHeaderSection />

          {/* Main sections */}
          <div className="flex flex-wrap">
            <DigitalSubscriptionSection />
            <SubscriptionCardsSection />
            <CalendarSection />
            <SearchSection />
            <MainContentSection />
          </div>

          {/* Bottom Navigation */}
          <BottomNavigationSection />
        </div>
      </div>
    </div>
  );
};
